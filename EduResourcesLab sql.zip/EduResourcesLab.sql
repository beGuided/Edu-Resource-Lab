-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 18, 2021 at 01:08 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `EduResourcesLab`
--

-- --------------------------------------------------------

--
-- Table structure for table `class_material`
--

CREATE TABLE `class_material` (
  `id` int(11) NOT NULL,
  `material_title` varchar(255) NOT NULL,
  `material_link` varchar(255) NOT NULL,
  `material_dept_id` varchar(255) NOT NULL,
  `material_level` varchar(255) NOT NULL,
  `material_semester` varchar(255) NOT NULL,
  `material_school` varchar(255) NOT NULL,
  `material_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_material`
--

INSERT INTO `class_material` (`id`, `material_title`, `material_link`, `material_dept_id`, `material_level`, `material_semester`, `material_school`, `material_image`) VALUES
(1, 'Agric dept', 'link', 'Agric', '100 level', 'First', 'Degree', 'image'),
(4, 'computer maths', 'computermaths.com', 'computer maths', '100 level', 'First', 'Nce', 'image'),
(5, 'maths', 'maths.com', 'Maths', '100 level', 'First', 'Degree', 'image'),
(6, 'chemistry', 'chemistery.com', 'Chemistry', '100 level', 'First', 'Degree', 'image'),
(8, 'Biology', 'biology.com', 'Biology ', '100 level', 'First', 'Degree', 'image'),
(9, 'Business', 'business.com', 'Business', '100 level', 'First', 'Degree', 'image'),
(10, 'computer', 'second computer.com', 'computer science ', '100 level', 'Second', 'Degree', 'image'),
(12, 'Agric', 'agric.com', 'Agric', '100 level', 'Second', 'Degree', 'image'),
(13, 'Maths', 'maths.com', 'Maths', '100 level', 'Second', 'Degree', 'image'),
(14, 'Biology', 'secondbiology.com', 'biology', '100 level', 'Second', 'Nce', 'image'),
(15, 'chemistry', 'chemistry.com', 'Chemistry', '100 level', 'First', 'Degree', 'image'),
(16, 'Business', 'business.com', 'Business', '100 level', 'Second', 'Degree', 'image'),
(17, 'computermaths', 'maths.com', 'computer maths', '200 level', 'Second', 'Nce', 'image'),
(25, 'computer maths', 'computer.com', 'computer maths', '100 level', 'Second', 'Nce', 'image');

-- --------------------------------------------------------

--
-- Table structure for table `degree_department`
--

CREATE TABLE `degree_department` (
  `id` int(11) NOT NULL,
  `dept_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `degree_department`
--

INSERT INTO `degree_department` (`id`, `dept_title`) VALUES
(1, 'computer science '),
(2, 'Agric'),
(4, 'Maths'),
(5, 'Chemistry'),
(6, 'Biology '),
(7, 'Business'),
(9, 'Edu Tech'),
(10, 'Home Economics');

-- --------------------------------------------------------

--
-- Table structure for table `nce_department`
--

CREATE TABLE `nce_department` (
  `id` int(11) NOT NULL,
  `dept_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nce_department`
--

INSERT INTO `nce_department` (`id`, `dept_title`) VALUES
(1, 'computer maths'),
(2, 'biology'),
(3, 'Business Education'),
(4, 'PED'),
(5, 'Chemistry');

-- --------------------------------------------------------

--
-- Table structure for table `past_question`
--

CREATE TABLE `past_question` (
  `id` int(11) NOT NULL,
  `question_title` varchar(255) NOT NULL,
  `question_link` varchar(255) NOT NULL,
  `question_dept_id` varchar(255) NOT NULL,
  `question_level` varchar(255) NOT NULL,
  `question_type` varchar(255) NOT NULL,
  `question_semester` varchar(255) NOT NULL,
  `question_school` varchar(255) NOT NULL,
  `question_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `past_question`
--

INSERT INTO `past_question` (`id`, `question_title`, `question_link`, `question_dept_id`, `question_level`, `question_type`, `question_semester`, `question_school`, `question_image`) VALUES
(11, 'computer', 'computer.com', 'computer science ', '100 level', 'Exam', 'First', 'Degree', 'image'),
(12, 'business', 'business.com', 'Business Education', '100 level', 'Exam', 'First', 'Nce', 'image'),
(13, 'business', 'business.com', 'Business', '100 level', 'Exam', 'First', 'Degree', 'image'),
(14, 'Biology', 'biology.com', 'biology', '100 level', 'Exam', 'First', 'Nce', 'image'),
(15, 'Biology', 'biology.com', 'Biology ', '100 level', 'Test', 'Second', 'Degree', 'image'),
(16, 'computer', 'Secons computer.com', 'computer science ', '100 level', '', 'Second', 'Degree', 'image'),
(17, 'Biology', 'second biology.com', 'biology', '100 level', 'Exam', 'Second', 'Nce', 'image'),
(20, 'computer maths', 'computermaths.com', 'computer maths', '100 level', 'Exam', 'First', 'Nce', 'image');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_department` varchar(255) NOT NULL,
  `user_role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `user_email`, `password`, `user_department`, `user_role`) VALUES
(1, 'mona', 'adejoh', 'mona', 'example@example.com', '123', 'science', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class_material`
--
ALTER TABLE `class_material`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `degree_department`
--
ALTER TABLE `degree_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nce_department`
--
ALTER TABLE `nce_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `past_question`
--
ALTER TABLE `past_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class_material`
--
ALTER TABLE `class_material`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `degree_department`
--
ALTER TABLE `degree_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `nce_department`
--
ALTER TABLE `nce_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `past_question`
--
ALTER TABLE `past_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
